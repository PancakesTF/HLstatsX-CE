<?php
header("Location:hlstats.php");
?>
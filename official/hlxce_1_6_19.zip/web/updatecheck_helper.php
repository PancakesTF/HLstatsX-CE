<?php
	echo file_get_contents('http://master.hlxce.com/updatecheck/');
?>

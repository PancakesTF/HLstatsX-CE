INSERT IGNORE INTO `hlstats_Actions` (`game`, `code`, `reward_player`, `reward_team`, `team`, `description`, `for_PlayerActions`, `for_PlayerPlayerActions`, `for_TeamActions`, `for_WorldActions`, `count`, `object`, `event`) VALUES
('dods', 'domination', 7, 0, '', 'Domination', '1', '', '', '', 0, NULL, NULL),
('dods', 'revenge', 5, 0, '', 'Revenge', '1', '', '', '', 0, NULL, NULL);